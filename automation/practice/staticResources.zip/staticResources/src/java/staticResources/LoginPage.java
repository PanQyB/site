package staticResources;

/**
 * Created by IntelliJ IDEA.
 * User: ab83625
 * Date: 10.11.2010
 * To change this template use File | Settings | File Templates.
 */
public class LoginPage extends Page {
    public static final String PAGE_URL = "http://www.testlogin.com/login.html";

    protected LoginPage() {
        super(PAGE_URL);
    }

    public static LoginPage openLoginPage() {
        LoginPage loginPage = new LoginPage();
        loginPage.getSelenium().open(PAGE_URL);
        return loginPage;
    }

    private void setUserName(String userName) {
        // код для заполнения поля Username
        getSelenium().type(buildLocator(getProperty("field.username.locator"),getProperty("field.username.arg")), userName);
    }

    private void setPassword(String password) {
        // код для заполнения поля Password
        getSelenium().type(buildLocator(getProperty("field.password.locator"), getProperty("field.password.arg")), password);
    }

    private void pushLoginButton() {
        // код для нажатия на кнопку Login
        getSelenium().click(buildLocator(getProperty("button.login.locator"), getProperty("button.login.arg")));
    }

    protected void parsePage() {
        // Разбор элементов страницы
        // Заполнение необходимых переменных данными со страницы
    }

    protected void init() {
        // Инициализация страницы
        // Проверка корректности загрузки
        if(!getSelenium().getLocation().equals(PAGE_URL)) {
            throw new IllegalStateException("Invalid page is opened");
        }
    }

    private void loginAs(String userName, String password) {
        setUserName(userName);
        setPassword(password);
        pushLoginButton();
    }

    public HomePage login(String userName, String password) {
        loginAs(userName, password);
        return new HomePage();
    }

    public ErrorLoginPage loginInvalid(String userName, String password) {
        loginAs(userName, password);
        return new ErrorLoginPage();
    }
}