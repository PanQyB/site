package staticResources;

import com.thoughtworks.selenium.DefaultSelenium;
import com.thoughtworks.selenium.Selenium;
import org.openqa.selenium.server.SeleniumServer;

/**
 * Created by IntelliJ IDEA.
 * User: ab83625
 * Date: 10.11.2010
 * To change this template use File | Settings | File Templates.
 */
public class Context {
    public static final String BROWSER_IE = "*iexplore";
    public static final String BROWSER_FF = "*firefox";
    public static final String BROWSER_CH = "*chrome";
    private static final String RESOURCES_PATH = "resources/${NAME}.properties";

    public static String siteUrl;
    private static Context context;
    private DataStorage dataStorage;
    private Selenium selenium;
    private SeleniumServer seleniumServer;

    private Context() {
        this.setDataStorage(DataStorage.getInstance());
    }

    public static void initInstance(String browserType, String siteURL) {
        context = new Context();
        siteUrl = siteURL;
        context.setSelenium(new DefaultSelenium("localhost", 4444, browserType, siteURL));
        context.start();
    }

    public static Context getInstance() {
        if (context == null) {
            throw new IllegalStateException("Context is not initialized");
        }
        return context;
    }

    public Selenium getSelenium() {
        if (selenium != null) {
            return selenium;
        }
        throw new IllegalStateException("WebBrowser is not initialized");
    }

    public void start() {
        try {
            seleniumServer = new SeleniumServer();
            seleniumServer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
        selenium.start();
    }

    public void close() {
        selenium.close();
        selenium.stop();
        seleniumServer.stop();
    }

    public String getSiteUrl() {
        return siteUrl;
    }

    public void setSelenium(Selenium selenium) {
        this.selenium = selenium;
    }

    public String getResourcesPath(String name) {
        return RESOURCES_PATH.replaceAll("\\$\\{NAME\\}", name);
    }

    private void setDataStorage(DataStorage dataStorage) {
        this.dataStorage = dataStorage;
    }

    public DataStorage getDataStorage() {
        return dataStorage;
    }
}