package staticResources;

import java.util.Properties;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: ab83625
 * Date: 10.11.2010
 * To change this template use File | Settings | File Templates.
 */
public class DataStorage {
    private Map<String, Properties> propertiesMap;

    private DataStorage() {
        this.propertiesMap = new HashMap<String, Properties>();
    }

    public static DataStorage getInstance() {
        return new DataStorage();
    }

    public void setProperty(String key, Properties properties) {
        propertiesMap.put(key, properties);
    }

    public Properties getProperty(String key) {
        return propertiesMap.get(key);
    }

    public boolean exists(String key) {
        return propertiesMap.get(key) != null;
    }
}