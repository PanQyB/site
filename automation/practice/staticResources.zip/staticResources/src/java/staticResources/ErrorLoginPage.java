package staticResources;

/**
 * Created by IntelliJ IDEA.
 * User: ab83625
 * Date: 10.11.2010
 * To change this template use File | Settings | File Templates.
 */
public class ErrorLoginPage extends Page {
    public static final String PAGE_URL = "http://www.testlogin.com/loginError.html";
    private String errorMessage;

    protected ErrorLoginPage() {
        super(PAGE_URL);
    }

    protected void init() {
        // Инициализация страницы
    }

    protected void parsePage() {
        this.errorMessage = getSelenium().getText(buildLocator(getProperty("text.errormessage.locator"), getProperty("text.errormessage.id")));
    }

    public String getErrorMessage() {
        return this.errorMessage;
    }

    public LoginPage backToLoginPage() {
        getSelenium().click(buildLocator(getProperty("link.backtologin.locator"), getProperty("link.backtologin.id")));
        return new LoginPage();
    }
}