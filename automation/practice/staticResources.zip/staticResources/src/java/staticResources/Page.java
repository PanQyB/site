﻿package staticResources;

import com.thoughtworks.selenium.Selenium;

import java.util.Properties;
import java.util.List;
import java.io.FileReader;
import java.io.File;
import java.io.IOException;

import org.apache.commons.lang.ClassUtils;

/**
 * Created by IntelliJ IDEA.
 * User: ab83625
 * Date: 10.11.2010
 * To change this template use File | Settings | File Templates.
 */
public abstract class Page {
    private Context context;
    private String currentPage;
    private Properties properties;

    protected Page(String pageUrl) {
        this.currentPage = pageUrl;
        setContext(Context.getInstance());
        initProperties();
        init();
        parsePage();
    }

    private void initProperties() {
        String className = getClass().getSimpleName();
        if (!getContext().getDataStorage().exists(className)) {
            this.properties = new Properties();
            List superClasses = ClassUtils.getAllSuperclasses(getClass());
            File file = null;
            for (int i = superClasses.size() - 2; i >= 0 ; i--) {
                Class aClass = (Class) superClasses.get(i);
                file = new File(getResourcesPath(aClass.getSimpleName()));
                if (getContext().getDataStorage().getProperty(aClass.getSimpleName())== null) {
                    if (file.exists()) {
                        putAllProperties(file);
                        updateStogare(aClass.getSimpleName(), getProperties());
                    }
                } else {
                    putAllProperties(getContext().getDataStorage().getProperty(aClass.getSimpleName()));
                }
            }
            file = new File(getResourcesPath(className));
            putAllProperties(file);
            updateStogare(this, getProperties());
        } else {
            setProperties(getContext().getDataStorage().getProperty(getClass().getSimpleName()));
        }
    }

    protected abstract void init();
    protected abstract void parsePage();

    private void setContext(Context instance) {
        this.context = instance;
    }

    public Context getContext() {
        return context;
    }

    public String getCurrentPage() {
        return context.getSiteUrl() + this.currentPage;
    }

    protected Selenium getSelenium() {
        return context.getSelenium();
    }

    private String getResourcesPath(String name) {
        return getContext().getResourcesPath(name);
    }

    private Properties getProperties() {
        return properties;
    }

    private void setProperties(Properties properties) {
        this.properties = properties;
    }

    protected String getProperty(String key) {
        return properties.getProperty(key);
    }

    private void putAllProperties(File proertiesFile) {
        try {
            this.properties.load(new FileReader(proertiesFile));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void putAllProperties(Properties properties) {
        this.properties.putAll(properties);
    }

    private void updateStogare(Object parentKeyObj, Properties properties) {
        updateStogare(parentKeyObj.getClass().getSimpleName(), properties);
    }

    private void updateStogare(String className, Properties properties) {
        getContext().getDataStorage().setProperty(className, (Properties)properties.clone());
    }

    protected String buildLocator(String type, String arg) {
        // Сервисный метода для создания Selenium локатора
        // по двум параметрам тип и аргумент
        return type + "=" + arg;
    }

    // ....
    // service methods...
    // ....
}